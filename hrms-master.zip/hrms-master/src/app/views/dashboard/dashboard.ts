import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  imports: [],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
  host: {
    class: 'flex flex-col gap-6 p-6',
  }
})
export class Dashboard {

}
