module.exports = {
  plugins: {
    '@tailwindcss/postcss': {},
    autoprefixer: {}, // Autoprefixer is generally good to have
  },
};